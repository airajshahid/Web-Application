<?php 
function sum($a, $b)
{
	# code...
	echo "Sum of a and b is ".($a+$b)."<br>";


}sum(100,10);

function sub($a, $b)
{
	# code...
	echo "sub of a and b is ".($a-$b)."<br>";


}sub(100,10);

function div($a, $b)
{
	# code...
	echo "Divide of a and b is ".($a/$b)."<br>";


}div(2,10);

function mul($a, $b)
{
	# code...
	echo "Multi of a and b is ".($a*$b)."<br>";


}mul(2,6);
 ?>