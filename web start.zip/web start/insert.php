
<!DOCTYPE html>
<html>
<head>
	<title>Data Insertion</title>
</head>
<body>

<table cellpadding="5" cellspacing="10" align="center">
	<center>
		<h3>Student Registration</h3>
	</center>
	<form method="post" action="#">
		<tr>
			<td>Name:
				<input type="text" name="name">
			</td>
		</tr>
		<tr>
			<td>Email:
				<input type="email" name="email">
			</td>
		</tr>
		<tr>
			<td>Contact details:
				<input type="text" name="contact">
			</td>
		</tr>
		<tr>
			<td>Gender:
				<input type="radio" name="gender" value="Male">Male |
				<input type="radio" name="gender" value="Female">Female
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<input type="submit" name="submit" value="Submit">
			</td>

		</tr>
	</form>
</table>

</body>
</html>
<?php 
$connection=mysqli_connect("localhost","root","");
	$db=mysqli_select_db($connection,'student_data');
	if (!$db) {
		
		echo mysqli_error($connection);
	}
	if ($_POST) {
		# code...
		$na=$_POST['name'];
		$em=$_POST['email'];
		$contact=$_POST['contact'];
		$gender=$_POST['gender'];
		$insert="insert into students(Name,Email,Contact_Details,Gender) values('$na','$em','$contact','$gender')";
		$query=mysqli_query($connection,$insert);
		if (!$query) {
			# code...
			echo mysqli_error($connection);
		}
		else
		{
			echo "<script>alert('Data Inserted Successfully!')</script>";
		}
	}
 ?>



 