<?php 
function sum($a, $b)
{
	# code...
	echo "Sum of a and b is ".($a+$b);


}sum(100,10);

 ?>