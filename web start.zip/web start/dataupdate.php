
<table cellpadding="5" cellspacing="10" align="center">
	<center>
		<h3>UPDATE DATA</h3>
	</center>
	<form method="post" action="">
		<tr>
			<td>
				Id:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
				<input type="text" name="id" id="id">
			</td>
		</tr>
		<tr>
			<td>
				Name:&nbsp&nbsp&nbsp
				<input type="text" name="name" id="name">
			</td>
		</tr>
		
		<tr>
			<td>Contact details:
				<input type="text" name="contact">
			</td>
		</tr>
		<tr>
			<td>Gender:
				<input type="radio" name="gender" value="Male">Male |
				<input type="radio" name="gender" value="Female">Female
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				
				<input type="submit" name="submit" value="Update" style="background-color: #2980b9; color: white; border: none; padding: 10px; margin: 20px">
			</td>
		</tr>
	</form>

</table>
<?php 
$connection=mysqli_connect("localhost","root","");
	$db=mysqli_select_db($connection,'student_data');
	
	if ($_POST) {
		# code...
		$id=$_POST['id'];
		$name=$_POST['name'];
		$contact=$_POST['contact'];
		
		$update="UPDATE students SET Name='$name',Contact_Details='$contact' WHERE Id='$id'";
		$query=mysqli_query($connection,$update);
		if(!$db){
			echo mysqli_error($connection);

		}
		else{
			echo "<script>alert('Data Update Successfully!')</script>";
		}
		}
 ?>