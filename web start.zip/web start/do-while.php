<?php 
$i=1;
do{
echo "do- while is"."<br>";
$i++;
}while ($i <= 10);

 ?>