<?php 
session_start();
echo "Welcome".$_SESSION['email1']."<br>";
echo "<a href='logout1.php'>Logout</a>";
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 	<br><br>
 	 <center><img src="img/b.png" height="200" width="400" alt=""></center>

 </body>
 </html>