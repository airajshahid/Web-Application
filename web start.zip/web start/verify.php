<?php

$myemail= "nimra@gmail.com";
$myemail1= "waqas@gmail.com";

$mypass="1234";
if (isset($_POST['login'])) {
	# code...
	$email=$_POST['email'];
	$email1=$_POST['email1'];

	$pass=$_POST['password'];
	if ($email==$myemail && $pass==$mypass) {
		# code...
		$rem=$_POST['remember'];
		if (isset($_POST['remember'])) {
			# code...
			setcookie('email',$email, time()+60*60*7);
		}
		session_start();
		$_SESSION['email']=$email;
		header("location:welcome.php");
	}
	else{
		echo "Email or password is invalid";
	}
if ($email1==$myemail1 && $pass==$mypass) {
		# code...
		$rem=$_POST['remember'];
		if (isset($_POST['remember'])) {
			# code...
			setcookie('email1',$email1, time()+60*60*7);
		}
		session_start();
		$_SESSION['email1']=$email1;
		header("location:welcome1.php");
	}
	else{
		echo "Email or password is invalid";
	}


}
else{
		header("location:23.php");
	}
  ?>





