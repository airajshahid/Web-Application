<?php 
session_start();
session_destroy();
echo "Loggedout Successfully.<br>";
echo "Click Here To <a href='23.php'>Login</a> again";
 ?>
