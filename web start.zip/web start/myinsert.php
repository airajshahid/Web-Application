<!DOCTYPE>
<head>
	<title>Data inserted my practices</title>
</head>
<boby>
	<center><h2>Student Data Inserted</h2></center>
	<center>
		<table cellspacing="10" cellpadding="5">
		<form method="post" action="#">
			<tr>
				<td>ID
					&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" name="id"></td>
			</tr>
			<tr>
				<td>Name
					<input type="text" name="name"></td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="submit" value="submit"></td>
			</tr>
			
			</form>
	</table>
</center>
</boby>
</html>
<?php
$connection= mysqli_connect("localhost","root","");
$db=mysqli_select_db($connection,'database');
if(!$db){
	echo mysqli_error($connection);
}
if($_POST){
	$id=$_POST['id'];
	$name=$_POST['name'];
	$insert="insert into students(id,name) values('$id','$name')";
	$query= mysqli_query($connection,$insert);

if(!$query){
	echo mysqli_error($connection);
}
else{
	echo "<script>alert('Data Inserted Successfully:)')</script>";
}
}
?>