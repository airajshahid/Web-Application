<table cellpadding="5" cellspacing="10" align="center">
	<center>
		<h3>Data Delete</h3>
	</center>
	<form method="post">
		<tr>
			<td>Registration:
				<input type="text" name="reg_no" id="reg_no"></td>
		</tr>
		<tr >
			<td colspan="2" align="center">
				<input type="submit" name="submit" value="Delete"></td>
		</tr>
	</form>
</table>
<?php 
$connection=mysqli_connect("localhost","root","");
	$db=mysqli_select_db($connection,'student_data');
	
	if ($_POST) {
		# code...
		$id=$_POST['reg_no'];
		$delete="DELETE FROM students WHERE Id='$id'";
		$query=mysqli_query($connection,$delete);
		if(!$db){
			echo mysqli_error($connection);

		}
		else{
			echo "<script>alert('Data Deleted Successfully!')</script>";
		}
		}
 ?>