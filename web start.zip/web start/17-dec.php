<!DOCTYPE html>
<html>
<head>
	<title>Order taking</title>
</head>
<body>
<form action="getdata.php" method="get">
	<center><h1>Shop</h1></center>
	<b>Deal:</b><br>
	Pizza Deal <input type="radio" name="deal" value="pizza deal"><br>
	Burger Deal	<input type="radio" name="deal" value="Burger Deal"><br>
	<br>	<b>Drink:</b><br>
	coca-cola <input type="checkbox" name="drink" value="coca"><br>
	Pepsi<input type="checkbox" name="drink" value="pepsi"><br>
	<br><b>your name:</b>
	<input type="text" name="name"><br>
	<br><b>your Email:</b>
	<input type="email" name="email"><br>
		<br><b>your Home Address:</b>
		<textarea name="address"></textarea> <br>
		<center></center><input type="submit" value="submit">


</form>

</body>
</html>