<?php 
session_start();
echo "Welcome".$_SESSION['email']."<br>";
echo "<a href='logout.php'>Logout</a>";
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 	
 	<br><br>
 <center><img src="img/a.png" height="200" width="200" alt=""></center>
 </body>
 </html>