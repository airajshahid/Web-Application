<style type="text/css" media="screen">
table{
	border: 2px solid black;
}	
th{
	text-align: right;
}
h3{
	text-align: center;
}
</style>

<table cellspacing="10" cellpadding="5" align="center">
	<h3>Login using session and cookies</h3>
	<form method="post" action="verify.php">
		<tr>
			<th>Email</th>
			<td>
				<input type="email" name="email">

			</td>
		</tr>
		<tr>
			<th>Email</th>
			<td>
				<input type="email" name="email1">

			</td>
		</tr>
		<tr>
			<th>Password</th>
			<td>
				<input type="password" name="password">
				
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<input type="checkbox" name="remember" value="1">
				Remember Me
			</td>
		</tr>
		<tr >
			<td colspan="2" align="center">
				<input type="submit" name="login" value="login">
			</td>
			
			
		</tr>
	</form>


</table>










