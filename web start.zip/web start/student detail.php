<!DOCTYPE html>
<html>
<head>
	<title>Student_record</title>
</head>
<body>
<table cellpadding="5" cellspacing="10" align="center">
	<center>
		<h1>Student Record</h1>
	</center>
	<form method="post">
		<tr>
			<td style="background-color: yellow;"><a href="insert.php" title="">Insert Data</a></td>
		</tr>
		<tr>
			<td style="background-color: orange"><a href="dataselection.php" title="">Select Data</a></td>
		</tr>
		<tr>
			<td style="background-color: white"><a href="dataupdate.php" title="">Update Data</a></td>
		</tr>
		<tr>
			<td style="background-color:pink"><a href="data deleted.php" title="">Delete Data</a></td>
		</tr>
	</form>
</table>
</body>
</html>