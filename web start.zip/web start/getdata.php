<?php 
echo "welcome  ".$_GET['name']."<br>";
echo "your Email ".$_GET['email']."<br>";
echo "your Address  ".$_GET['address']."<br>";
echo "your Deal is  ".$_GET['deal']."<br>";
echo "your drink is  ".$_GET['drink']."<br>"; ?>


































