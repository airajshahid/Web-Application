
<head>
	<meta charset="utf-8">
	<title>DATA SELECTION</title>
	<style type="text/css">
		th{
			text-align: center;
			border: 2px solid black;
			padding-left: 10px;
			padding-right: 10px;
			padding-top: 5px;
			padding-bottom: 5px;
		}
		td{
			text-align: center;
			border: 2px solid black;
			padding-left: 50px;
			padding-right: 50px;
			padding-top: 10px;
			padding-bottom: 10px;
		}
	</style>
</head>
<?php 
$connection=mysqli_connect("localhost","root","");
	$db=mysqli_select_db($connection,'student_data');
	$query="Select * From students";
	if ($query2=mysqli_query($connection, $query)) {
		# code...
		if(mysqli_num_rows($query2)>0){
			echo "<table>";
			echo "<tr>";
			echo "<th>Id</th>";
			echo "<th>Name"."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp"."</th";
			echo "<th>Contact_Details"."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp"."</th";
			echo "<th>Gender</th";
			echo "</tr>";

		}
		while($row=mysqli_fetch_array($query2)){
			echo "<tr>";
			echo "<td>".$row['Id']."</td>";
			echo "<td>".$row['Name']."</td>";
			echo "<td>".$row['Contact_Details']."</td>";
			echo "<td>".$row['Gender']."</td>";
			echo "</tr>";
		}
		echo "</table>";
	}
	else{
		echo "Record not found";

			}
mysqli_close($connection);
?>







