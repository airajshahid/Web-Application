<!DOCTYPE html>
<html>
<head>
	<title>hrml,php,css</title>
</head>
<style type="text/css" media="screen">
	h1{
		background-color: red;
	}
	div{
		background-size: yellow;
	}
</style>
<body>
	<h1>Hello</h1>
<div>
	<?php echo "Hello, World"; ?>
</div>
</body>
</html>