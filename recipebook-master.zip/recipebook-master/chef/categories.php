<?php
require_once('edit_template.php');
editPage('categories',$fieldInfo['categories']);
