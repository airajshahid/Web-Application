<?
require_once('edit_template.php');
editPage('ingredients',$fieldInfo['ingredients']);
