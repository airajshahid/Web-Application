<?php
require_once('edit_template.php');
editPage('recipes',$fieldInfo['recipes']);
