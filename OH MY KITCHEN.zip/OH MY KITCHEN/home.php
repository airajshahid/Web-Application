<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initia;-scale=1.0">
<title>FoodSeaS</title>
<link rel="stylesheet" type ="text/css" href="plz.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
	<header>
	<!-- navigation bar -->
	<div class="navbar">
		<ul>
			<li>
				<a href="#home">
					<div class="icon">
						<i class="fa fa-home" aria-hidden="true"></i>
						<i class="fa fa-home" aria-hidden="true"></i>
					</div>
					<div class="name"><span data-text="home">home</span></div>
				</a>
			</li>
			<li>
				<a href="#cetagories">
					<div class="icon">
						<i class="fa fa-hand-peace-o" aria-hidden="true"></i>
						<i class="fa fa-hand-peace-o" aria-hidden="true"></i>
					</div>
					<div class="name"><span data-text="cetagories">cetagories</span></div>
				</a>
			</li>
			<li>
				<a href="#about">
					<div class="icon">
                    <i class="fa fa-user-circle" aria-hidden="true"></i>
                    <i class="fa fa-user-circle" aria-hidden="true"></i>
					</div>
					<div class="name"><span data-text="about">about</span></div>
				</a>	
			</li>
			<li>
				<a href="#experts">
					<div class="icon">
						<i class="fa fa-spoon" aria-hidden="true"></i>
						<i class="fa fa-spoon" aria-hidden="true"></i>
					</div>
					<div class="name"><span data-text="experts">experts</span></div>
				</a>
			</li>
			
		</ul>
    </div>
    </header>
    <div class="hero__section">
    	<div class="hero__text">
    		<h1>oh my, kitchen</h1>
    		<p>Eat whatever you want, and if someone tries to lecture you about your weight, eat them too!</p>
    	</div>
    </div>
    <section class="about" id="about">
    		<div class="row">
    			<div class= "co150">
    				<h2 class="titleText"><span>A</span>bout us</h2>
    				<p>“If woman could see the sparks of light going forth from her fingertips when she is cooking and the substance of light that goes into the food she handles, she would be amazed to see how much of herself she charges into the meals that she prepares for her family and friends.It is one of the most important and least understood activities of life-that the radiation and feeling that go into the preparation of food affect everyone who partakes of it, and this activity should be unhurried, peaceful and happy.<br><br>It would be better that an individual did not eat at all than to eat food that has been prepared under a feeling of anger, resentment, depression or an outward pressure, because the substance of the lifestream performing the service flows into that food and is eaten and actually becomes part of the energy of the receiver.<br><br>That is why the advanced spiritual teachers of the East never eat food prepared by anyone other than their own chelas. Conversely, if the one preparing the food is the only one in the household who is spiritually advanced and an active charge of happiness, purity and peace pours forth into the food from him, this pours forth into the other members and blesses them.<br><br>I might say that there are more ways than one of allowing the Spirit of God to enter the flesh of man.” </p>
    			</div>
    			<div class ="co150">
    				<div class= "imgBx">
    					<img src="33.jpg">
    				</div>
    			</div>
    		</div>
    </section>
    <section class="cetagories" id="cetagories">
    	<div class="title">
    		<h2 class="titleText"><span>C</span>etagories</h2>
    		<p>“Real cooking is more about following your heart than following recipes.”</p>
    	</div>
    	<div class="content">
    		<div class="box">
    			<div class="imgBx">
    				<img src="sa3.jpg">
    		    </div>
    		    <div class="text">
    			<h3>special salad</h3>
    			<p>“my salad days, When I was green in judgement, cold in blood.” </p>
    		    </div>
    	    </div>
    	    <div class="box">
    			<div class="imgBx">
    				<img src="ch1.jpg">
    		    </div>
    		    <div class="text">
    			<h3>Grilled Chicken</h3>
                <p>Chicken! Aaah! The great heavenly blessing of the gods.</p>
    		    </div>
    	    </div>
    	    <div class="box">
    			<div class="imgBx">
    				<img src="br1.jpg">
    		    </div>
    		    <div class="text">
    			<h3>Miss Biryani</h3>
                <p>“If You like biryani with Aloo Your mentally disturbed.” </p>
    		   </div>
    		</div>
    		<div class="box">
    			<div class="imgBx">
    				<img src="fs1.jpg">
    		    </div>
    		    <div class="text">
    			<h3>Fish</h3>
                <p >Remember folks, fish are like relatives. After two days, they stink.</p>
    		    </div>
    		</div>
    		<div class="box">
    			<div class="imgBx">
    				<img src="re5.jpg">
    		    </div>
    		    <div class="text">
    			<h3>desert</h3>
                <p>To see the desert is like peeling the skin off a landscape.</p>
    		    </div>
    		</div>
    		<div class="box">
    			<div class="imgBx">
    				<img src="bv1.jpg">
    		    </div>
    		    <div class="text">
    			<h3>Beverages</h3>
                <p>A Sun and Sand, Drink in hand have some Fun....Yeah</p>
    		    </div>
    		</div>
    	</div>
        <div class ="title">
            <a href="http://localhost/list.php" class="btn"><i class="fa fa-eye" aria-hidden="true"></i></a>
        </div>
    </section>
    <section class="experts" id="experts">
        <div class="title">
            <h2 class="titleText">Our Kitchen <span>E</span>xperts</h2>
            <p>“Kitchens are made for bringing families together.”</p></div>
            <div class="content">
            <div class="box">
                <div class="imgBx">
                    <img src="ex1.jpg">
                </div>
                <div class="text">
                    <h3>Someone Famous</h3>
            </div>
            </div>
                <div class="box">
                <div class="imgBx">
                    <img src="ex2.jpg">
                </div>
                <div class="text">
                    <h3>Someone Famous</h3>
                </div>
            </div>
             <div class="box">
                <div class="imgBx">
                    <img src="ex3.jpg">
                </div>
                <div class="text">
                    <h3>Someone Famous</h3>
                </div>
            </div>
            <div class="box">
                <div class="imgBx">
                    <img src="ex5.jpg">
                </div>
                <div class="text">
                    <h3>Someone Famous</h3>
                </div>
            </div>
        </div>
    </section>
    <script type="text/javascript">
    		window.addEventListener('scroll',function(){
    			const header = document.querySelector('header');
    			header.classList.toggle("sticky", window.scrollY > 0);
    		});
    </script>
</body>	
</html>
