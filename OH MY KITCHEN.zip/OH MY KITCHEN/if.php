if (!$db)
 {
	echo mysqli_error($connection);
}
if ($_POST)
{
	$na=$_POST['name'];
	$insert="insert into students (name) values('$na')";
	$query=mysql_query($connection, $insert);
	if (!$query)
	{
		echo mysqli_error($connection);
	}
	else
	{
		echo "<script>alert('Data Inserted Successfully!')</script>"
	}
  }
?>