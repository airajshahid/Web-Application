<?php
$con = new mysqli("localhost","root","","login1");

// Check connection
if (!$con) 
{
	echo "error in connection";
}

if (isset($_POST['submit'])) {
	$email=$_POST['email'];
	$pass=$_POST['pass'];
  	$sql = "SELECT * FROM login_table WHERE email='".$email."' AND pass='".$pass."'";
	$result = mysqli_query($con, $sql);
	if (mysqli_num_rows($result) > 0) 
	{
		
		header('location:mainpage.html');
	} 
	else {
	  $error="password doesn't match ";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="loginform Style.css">
</head>
<body>
	<div class="loginbox">
	<h1>Login Here</h1>
	<form method="post" action="">
		<p>User Name</p>
		<input type="text" name="email" placeholder="Enter Email">
		<p>Password</p>
		<input type="Password" name="pass" placeholder="Enter Password">
		<button type="submit" name="submit" class="signupbtn" >LOG IN</button><br>
        <a href="12.php">Don't have an account?</a>
	</form>
</div>
</body>
</html>