<?
if(!$db)
{
	echo mysqli_error($connection);
}
if ($_POST)
{
	$na=$_POST['fname'];
	$insert="insert into students (fname) values('$na')";
	$query=mysql_query($connection, $insert);
	if (!$query)
	{
		echo mysqli_error($connection);
	}
	else
	{
		echo "<script>alert('Data Inserted Successfully!')</script>"
	}
  }
?>
<table cellpadding="5" cellpadind="10" align= "center">
	<center>
		<h3>
			Student Registration
		</h3>
	</center>
	<form method ="post" action ="#">
		<tr>
			<td>
				Name:
				<input type="text" fname="fname">
				</td>>
					</tr>
					<tr>
						<td colspan="2" align="center">
							<input type="submit"fname="submit" value="submit">
						</td>
					</tr>
				</form>
</table>
