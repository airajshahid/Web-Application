<head>
<title>selection</title>
</head>
<style type="text/css">
	th{
		text-align: center;
		border: 2px solid black;
		padding-right: 10px;
		padding-left: 10px;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	td{
		text-align: center;
		border: 2px solid black;
		padding-right: 50px;
		padding-left: 50px;
		padding-top: 10px;
		padding-bottom: 10px;
	}
</style>
<?php
$connection=mysqli_connect("localhost","root","");
$db=mysqli_select_db($connection, 'students_data');
$query="select* FROM student";
if ($query2=mysqli_query($connection, $query))
{
	if(mysqli_num_rows($query2)>0)
	{
		echo"<table>";
		echo "<tr>";
		echo "<th>Id</th";
		echo "<th>Name</th";
		echo "</tr";
	}
	while ($row=mysqli_fetch_array($query2))
	{
		echo "<tr>";
		echo "<td>".$row['id']."</td>";
		echo "<td>".$row['name']."</td>";
		echo "</tr>";

	}
	echo "</table";

}
else
{
	echo "Records not found";
}
mysqli_close($connection);
?>