<?php
$con = new mysqli("localhost","root","");
// Check connection
if ($con) {
 // echo "connection is ok ";
}
else{
 echo "error in connection";
}
if (isset($_POST['login'])) {
  $fname=$_POST['fname'];
 $email=$_POST['email'];
 $pass=$_POST['pass'];
// Validate password strength
 $uppercase = preg_match('@[A-Z]@', $pass);
$lowercase = preg_match('@[a-z]@', $pass);
$number = preg_match('@[0-9]@', $pass);
$specialChars = preg_match('@[^\w]@', $pass);
if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($pass) < 8) {
 echo 'Password should be at least 8 characters in length and should include at least one upper case
letter, one number, and one special character.';
}

else{
 echo 'Strong password.';
 header("location:newlogin.php");
}
 //$cpass=$_POST['cpass'];
 //if($pass==$cpass)
 {
 // print_r($_POST); check the values are coming or not from form
 $insert = mysqli_query($con, "INSERT INTO login_table (fname, email,
pass)VALUES ('".$fname."','".$email."', '".$pass."')");
if ($insert) {
 // echo "data is inserted in db";
}else{
 echo "data is not inserted in db";
}
}
//else
{
   //echo "does not match";
}
}
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="signupP.css">
</head>
<body>
 
<div class="signupbox">
  <h1>SIGNUP HERE</h1>
  <form method="post" action="">
    <p>Email</p>
    <input type="text" name="fname" placeholder="Enter Name">
    <p>Email</p>
    <input type="text" name="email" placeholder="Enter Email">
    <p>Password</p>
    <input type="Password" name="pass" placeholder="Enter Password">
    <button type="submit" name="login">SIGN UP</button>
       
  </form>
</body>
</html>

