<table cellpadding="5" cellspacing="10" align="center">
	<center>

		<h3>
			Updata Data
		</h3>
	</center>
	<form method="post" action="">
		<tr>
			<td>
				Registration:
				<input type="test"name="reg_no" id="reg_no">
			</td>
		</tr>
		<tr>
			<td>
				Name:&nbsp&nbsps&nbs&nbs&nbs&nbs&nbs&nbs&nbs&nbs;
				<input type="" name="name" id="name">
			</td>
			<tr>
				<td colspan="2" align="center">
					<input type="submit" name="submit" value="Updata">
				</td>
			</tr>
</form>
</table>
<?php>
$conn=mysqli_connection("localhost", "root","");
$db=mysqli_select_db($connection, 'students_data');
if($_POST)
{
	$reg=$_POST['reg_no'];
	$name=$_POST['name'];
	$update="UPDATE student SET name='$name'WHERE id='$reg'";
	$query=mysqli_query($conn, $update);
	if(!$db)
	{
		echo mysqli_error($connection);
	}
	else
	{
		echo"<script>alert('data updateed successfully')</script>
	}

}
?>


