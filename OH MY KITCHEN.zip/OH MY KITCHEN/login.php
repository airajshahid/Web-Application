<?php

$host="localhost";
$user="root";
$password="";
$db="demo";


mysql_connect($host, $user, $password);
mysql_select_db($db)

if (isset($_POST['login'])) {
  $username=$_POST['user'];
 $password=$_POST['password'];
 $email=$_POST['email'];

 $sql="select * from login where user='".$uname."' AND Pass='".$password."' limit 1";

$result = mysqli_query($sql);

  if (mysqli_num_rows($result) > 0) 
  {
    
    header('location:file:///C:/xampp/htdocs/A/hhh.html');
  } 
  else {
    $error="password doesn't match ";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="signupP.css">
</head>
<body>
 <div class="container">
  <img src="log.png">
  <form method="$POSTt" action="#">
    <div class="form_input">
    <input type="text" name="username" placeholder="Enter Your Name">
  </div>
  <div class="form_input">
    <input type="text" name="email" placeholder="Enter Your emailaddress">
  </div>
  <div class="form_input">
  <input type="text" name="Password" placeholder="Enter Your Password">
  </div>
  <input type="submit" name="submit" value="LOGIN" class="btn-login"/>
  </form>
</body>
</html>