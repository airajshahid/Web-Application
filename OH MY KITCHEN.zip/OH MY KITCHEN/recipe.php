<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type ="text/css" href="recipe.css">
	<link rel="stylesheet" href="css/bootstrap-grid.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<title>Grilled chicken</title>
</head>
<body>
	<div class=head>
		<h1>Grilled Chicken</h1>
		<p>Say goodbye to dry, bland grilled chicken breasts. This recipe guarantees juicy, flavorful chicken every time</p>
	</div>	
	<h2>Ingredients</h2>
</div>
	<ul>
		<li>1-3/4 lbs boneless, skinless chicken breasts</li>
        <li>6 tablespoons extra virgin olive oil</li>
        <li>4 large garlic cloves, minced<li>
        <li>1 teaspoon dried thyme</li>
        <li>1/2 teaspoon dried oregano<li>
        <li>1-1/4 teaspoon salt<li>
        <li>1/2 teaspoon freshly ground black pepper</li>
	</ul>
</div>
	<h2>Method</h2>
	<ol>
		<li>
			One at a time, place the chicken breasts in a 1-gallon zip-lock bag; using a meat mallet, pound to an even ½-inch thickness.
		</li>
		<li>
			Mix all of the ingredients except for the chicken together in a 1-gallon zip-lock bag (go ahead and use the same one you used for pounding if it is still in good shape). Add the chicken breasts to the bag and massage the marinade into the meat until evenly coated. Seal the bag and place in a bowl in the refrigerator (the bowl protects against leakage); let the chicken marinate for at least 4 hours or overnight.
		</li>
		<li>
			Preheat the grill to high heat and oil the grates. Place the chicken breasts on the grill and cook, covered, for 2 to 3 minutes per side. Do not overcook. Transfer the chicken to a platter and serve.
		</li>
	</ol>
	<div class ="title">
            <a href="http://localhost/home.php" class="btn"><i class="fa fa-home" aria-hidden="true"></i></a>
        </div>
     <div class ="title">
        <a href="http://localhost/list.php" class="btn"><i class="fa fa-cutlery" aria-hidden="true"></i></a>
    </div>
</div>
</body>
</html>
