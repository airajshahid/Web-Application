<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="css/bootstrap-grid.css">
	<link rel="stylesheet" type ="text/css" href="list.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
	<marquee bgcolor="grey" mwidth="60%" direction="right" height="100px">
	<h1>lets made food with love</h1>
    </marquee>
    <section class="recipe__section">
    		<div class="content">
    			<div class="box">
    				<img src="ch1.jpg" alt="">
    				<div class="info">
    		    	<h3>chicken BBQ</h3>
    		    	<p> fuck hfg gfgh ftyffyu gdyhvhv dydfgg ydtfuv txtf</p>
    		    	<a href="#"><a href="http://localhost/recipe.php"class="button">view</a>
    		    </div>
    	        </div>
    	        <div class="box">
    				<img src="sa2.jpg" alt="">
    				<div class="info">
    		    	<h3>Russian Salad</h3>
    		    	<p>put some love and make bbq chicken</p>
    		    	<a href="#"><a href="http://localhost/recipe.php"class="button">view</a>
                    </div>
    	        </div>
    	        <div class="box">
    				<img src="sa2.jpg" alt="">
    				<div class="info">
    		    	<h3>Oh!Salad</h3>
    		    	<p>Food is incomplete without #SALAD</p>
    		    	<a href="#"><a href="http://localhost/recipe.php"class="button">view</a>
    	            </div>
    	        </div>
    	        <div class="box">
    				<img src="bs.jpg" alt="">
    		        <div class="info">
    		    	<h3>Egg</h3>
    		    	<p>lets see hoe to makeeeee.</p>
    		    	<a href="#"><a href="http://localhost/recipe.php"class="button">view</a>
    	            </div>
    	        </div>
    	        <div class="box">
    				<img src="fs3.jpg" alt="">
    		        <div class="info">
    		    	<h3>Fish</h3>
    		    	<p>Fish isnt 1st priority</p>
    		    	<a href="#"><a href="http://localhost/recipe.php"class="button">view</a>
    	            </div>
    	        </div>
    	        <div class="box">
    				<img src="f6.jpg" alt="">
    		        <div class="info">
    		    	<h3>Veges</h3>
    		    	<p>Vegs help us to maintain health</p>
    		    	<a href="#"><a href="http://localhost/recipe.php"class="button">view</a>
    	            </div>
    	        </div>
    	        <div class="box">
    				<img src="pi1.jpg" alt="">
    		        <div class="info">
    		    	<h3>Pizza</h3>
    		    	<p>real taste of lust</p>
    		    	<a href="#"><a href="http://localhost/recipe.php"class="button">view</a>
    	            </div>
    	        </div>
    	    </div>
    </section>
    <div class ="title">
            <a href="http://localhost/home.php" class="btn"><i class="fa fa-hand-o-left" aria-hidden="true"></i></a>
            <a href="http://localhost/recipe.php" class="btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
    </div>
</body>