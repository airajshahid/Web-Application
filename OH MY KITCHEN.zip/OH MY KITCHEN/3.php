?php


$servername = "localhost";
$username = "root";
$password = "password";

// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE MYDB";
if ($conn->query($sql) === TRUE) {

    echo "1. Database created successfully <br/>";
    $conn->select_db("MYDB");


    $sql_members = "CREATE TABLE MEMBERS (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    USERNAME VARCHAR(30) NOT NULL,
    EMAIL VARCHAR(40) NOT NULL,
    DISCOUNT VARCHAR(5),
    PASSW CHAR(128),
    ROLE VARCHAR(9)
    )";


    if ($conn->query($sql_members) === TRUE) {
        echo "2. Table MEMBERS created successfully <br/>";
    } else {
        echo "Error creating table: " . $conn->error;
    }

    $sql_content = "CREATE TABLE CONTENT (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    TITLE VARCHAR(30) NOT NULL,
    TEXT VARCHAR(30) NOT NULL
    )";

    if ($conn->query($sql_content) === TRUE) {
        echo "3. Table CONTENT created successfully <br/>";
    } else {
        echo "Error creating table: " . $conn->error;
    }



} else {
    echo "Error creating database: " . $conn->error;
}

$conn->close();


?>