<?php


$servername = "localhost";
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE books_data";
if ($conn->query($sql) === TRUE) {

    echo "1. Database created successfully <br/>";
    $conn->select_db("MYDB");


    $sql_members = "CREATE TABLE book_details (
    book_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    book_name VARCHAR(30) NOT NULL,
    author_name VARCHAR(40) NOT NULL,
    date_published VARCHAR(30),
    price INT(6),
    )";


    if ($conn->query($sql_members) === TRUE) {
        echo "2. Table MEMBERS created successfully <br/>";
    } else {
        echo "Error creating table: " . $conn->error;
    }
    $sql =INSERT INTO `book_details` (`book_id`, `book_name`, `author_name`, `date_published`, `price`) VALUES
    (1, 'Peter Brown', 'Ramzan', '07-12-1999', '500');
    (2, 'harry Brown', 'Ibrahim', '03-19-1998', '900');
    (3, 'alexa burn', 'Mussa', '17-12-2000', '300');
    (4, 'arina Brown', 'Airaj', '08-12-1999', '200');
    if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
   } else {
  echo "Error: " . $sql . "<br>" . $conn->error;
   }

    $sql_content = "CREATE TABLE authors_data (
    First_name VARCHAR(30),
    last_name VARCHAR(30) NOT NULL,
    dob VARCHAR(30) NOT NULL,
    no_of_book VARCHAR(30) NOT NULLUNSIGNED AUTO_INCREMENT PRIMARY KEY,
    )";

    if ($conn->query($sql_content) === TRUE) {
        echo "3. Table CONTENT created successfully <br/>";
    } else {
        echo "Error creating table: " . $conn->error;
    }
    $sql =INSERT INTO `authors_data` (`First_name`, `Last_name`, `dob`, `no_of_book`,) VALUES
    ('Ramzan', 'ciftan', '2-1-1400' '1');
    ('Ibrahim', 'Ali', '12-2-1670' '2');
    ('Mussa', 'Ali', '8-10-1550' '3');
    ('Airaj', 'Ahmad', '1-12-1660' '4');
    if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
   } else {
  echo "Error: " . $sql . "<br>" . $conn->error;
   }

} else {
    echo "Error creating database: " . $conn->error;
}
 $sqli=SELECT book_details.book_id, book_details.author_name, authors_data.no_of_book
  FROM book_details
INNER JOIN authors_data ON book_details.book_id=authors_data.no_of_book;

$conn->close();


?>